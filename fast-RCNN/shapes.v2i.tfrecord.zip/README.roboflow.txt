
shapes - v2 2021-03-02 3:56pm
==============================

This dataset was exported via roboflow.ai on March 2, 2021 at 8:01 AM GMT

It includes 193 images.
Triangle are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* 50% probability of vertical flip
* Randomly crop between 0 and 20 percent of the image
* Random exposure adjustment of between -25 and +25 percent
* Random Gaussian blur of between 0 and 1.25 pixels
* Salt and pepper noise was applied to 5 percent of pixels


